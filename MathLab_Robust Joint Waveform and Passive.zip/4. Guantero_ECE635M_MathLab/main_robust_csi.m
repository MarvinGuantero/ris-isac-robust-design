%% Robust Waveform Design for RIS-ISAC under Imperfect CSI
% This code extends the original work by incorporating CSI uncertainty
% Author: [Your Name]
% Date: March 2026

close all; clear all; clc;

%% ========================================================================
%  SIMULATION PARAMETERS
%  ========================================================================

% System Parameters
N = 20;         % Number of antennas at base station
K = 4;          % Number of communication users
M = 30;         % Number of symbols
L = 16;         % Number of RIS elements

% Power and SNR Settings
P0_dbm = 20;                        % Transmit power in dBm
P0 = 10^(P0_dbm/10) / 1e3;         % Convert to linear scale
SNR_dB_set = [0:2:10];             % SNR range for evaluation
rho = 0.2;                          % Trade-off parameter (radar vs. comm)

% CSI Error Parameters (NEW)
epsilon_set = [0, 0.05, 0.1, 0.15, 0.2];  % CSI error bounds
% epsilon = 0 means perfect CSI
% epsilon > 0 means bounded CSI error

% Algorithm Parameters
max_iteration = 100;                % Maximum iterations for optimization
convergence_threshold = 0.01;       % Convergence tolerance
Num_iter = 50;                      % Number of Monte Carlo iterations (reduced for debugging)

% Load desired radar pattern
load Rd.mat;
F = chol(Rd);

%% ========================================================================
%  INITIALIZATION OF RESULT STORAGE
%  ========================================================================

% Results storage for different CSI error levels
results = struct();
for eps_idx = 1:length(epsilon_set)
    eps = epsilon_set(eps_idx);
    results(eps_idx).epsilon = eps;
    results(eps_idx).rate_perfect = zeros(length(SNR_dB_set), Num_iter);
    results(eps_idx).rate_robust = zeros(length(SNR_dB_set), Num_iter);
    results(eps_idx).rate_nonrobust = zeros(length(SNR_dB_set), Num_iter);
    results(eps_idx).radar_performance = zeros(length(SNR_dB_set), Num_iter);
end

%% ========================================================================
%  MAIN MONTE CARLO SIMULATION LOOP
%  ========================================================================

fprintf('\n=======================================================\n');
fprintf('Starting Robust RIS-ISAC Simulation\n');
fprintf('=======================================================\n\n');

for mc_iter = 1:Num_iter
    
    % Generate random symbol sequence
    S = randi(2, K, M) * 2 - 3;  % BPSK symbols: {-1, +1}
    
    % Generate TRUE channels (unknown to the system)
    [H_bu_true, H_br_true, H_ru_true] = generate_channels(N, K, L);
    
    for snr_idx = 1:length(SNR_dB_set)
        SNR_dB = SNR_dB_set(snr_idx);
        SNR = 10^(SNR_dB/10);
        N0 = 1/SNR;
        
        % ============================================================
        % COMPUTE PERFECT CSI BASELINE ONCE (uses true channels)
        % This is the upper bound - only computed for epsilon=0 case
        % ============================================================
        [X_perfect, THETA_perfect] = ...
            robust_waveform_design(H_bu_true, H_br_true, H_ru_true, ...
            S, F, M, P0, rho, N0, L, max_iteration, ...
            convergence_threshold, 0); % No robustness needed
        
        % Evaluate on true channels
        H_perfect = H_bu_true + H_ru_true * THETA_perfect * H_br_true;
        rate_perfect = compute_sum_rate(H_perfect, X_perfect, S, N0, K);
        
        % Store perfect CSI result for ALL epsilon values (it's the baseline)
        for eps_idx = 1:length(epsilon_set)
            results(eps_idx).rate_perfect(snr_idx, mc_iter) = rate_perfect;
        end
        
        %% Test for each CSI error level (skip epsilon=0 since we already did perfect)
        for eps_idx = 1:length(epsilon_set)
            epsilon = epsilon_set(eps_idx);
            
            if epsilon == 0
                % Perfect CSI case - already computed above
                results(eps_idx).rate_robust(snr_idx, mc_iter) = rate_perfect;
                results(eps_idx).rate_nonrobust(snr_idx, mc_iter) = rate_perfect;
                results(eps_idx).radar_performance(snr_idx, mc_iter) = 0;
                continue;  % Skip to next epsilon
            end
            
            % Generate estimated channels with CSI errors
            [H_bu_est, H_br_est, H_ru_est] = ...
                generate_channels_with_error(H_bu_true, H_br_true, ...
                                             H_ru_true, epsilon);
            
            %% Method 1: Robust design (assumes worst-case CSI error)
            [X_robust, THETA_robust] = ...
                robust_waveform_design(H_bu_est, H_br_est, H_ru_est, ...
                S, F, M, P0, rho, N0, L, max_iteration, ...
                convergence_threshold, epsilon);  % WITH robustness
            
            % Evaluate on TRUE channels (reality check)
            H_robust = H_bu_true + H_ru_true * THETA_robust * H_br_true;
            rate_robust = compute_sum_rate(H_robust, X_robust, S, N0, K);
            results(eps_idx).rate_robust(snr_idx, mc_iter) = rate_robust;
            
            %% Method 2: Non-robust design (ignores CSI uncertainty)
            [X_nonrobust, THETA_nonrobust] = ...
                robust_waveform_design(H_bu_est, H_br_est, H_ru_est, ...
                S, F, M, P0, rho, N0, L, max_iteration, ...
                convergence_threshold, 0);  % WITHOUT robustness (treats as perfect)
            
            % Evaluate on TRUE channels (this is where it fails!)
            H_nonrobust = H_bu_true + H_ru_true * THETA_nonrobust * H_br_true;
            rate_nonrobust = compute_sum_rate(H_nonrobust, X_nonrobust, S, N0, K);
            results(eps_idx).rate_nonrobust(snr_idx, mc_iter) = rate_nonrobust;
            
            % Compute radar performance (how well it matches desired pattern)
            radar_perf = norm(F' * (X_robust - X_perfect), 'fro')^2;
            results(eps_idx).radar_performance(snr_idx, mc_iter) = radar_perf;
        end
    end
    
    % Progress display
    if mod(mc_iter, 10) == 0 || mc_iter == 1
        fprintf('Progress: %d/%d iterations completed (%.1f%%)\n', ...
                mc_iter, Num_iter, 100*mc_iter/Num_iter);
    end
end

%% ========================================================================
%  COMPUTE AVERAGE RESULTS
%  ========================================================================

fprintf('\n=======================================================\n');
fprintf('Computing average results...\n');
fprintf('=======================================================\n\n');

for eps_idx = 1:length(epsilon_set)
    results(eps_idx).rate_perfect_avg = mean(results(eps_idx).rate_perfect, 2);
    results(eps_idx).rate_robust_avg = mean(results(eps_idx).rate_robust, 2);
    results(eps_idx).rate_nonrobust_avg = mean(results(eps_idx).rate_nonrobust, 2);
    results(eps_idx).radar_performance_avg = mean(results(eps_idx).radar_performance, 2);
    
    % Compute standard deviations for error bars (optional)
    results(eps_idx).rate_robust_std = std(results(eps_idx).rate_robust, 0, 2);
    results(eps_idx).rate_nonrobust_std = std(results(eps_idx).rate_nonrobust, 0, 2);
end

%% ========================================================================
%  SANITY CHECK: Verify ordering is correct
%  ========================================================================

fprintf('Sanity Check at SNR = %d dB:\n', SNR_dB_set(end));
fprintf('%-10s %-15s %-15s %-15s\n', 'Epsilon', 'Perfect', 'Robust', 'Non-Robust');
fprintf('----------------------------------------------------------\n');

for eps_idx = 1:length(epsilon_set)
    fprintf('%-10.2f %-15.2f %-15.2f %-15.2f\n', ...
            epsilon_set(eps_idx), ...
            results(eps_idx).rate_perfect_avg(end), ...
            results(eps_idx).rate_robust_avg(end), ...
            results(eps_idx).rate_nonrobust_avg(end));
    
    % Verify ordering: Perfect >= Robust >= Non-Robust
    if results(eps_idx).rate_perfect_avg(end) < results(eps_idx).rate_robust_avg(end) - 0.01
        warning('⚠ Perfect CSI is worse than Robust! Something is wrong.');
    end
    if results(eps_idx).rate_robust_avg(end) < results(eps_idx).rate_nonrobust_avg(end) - 0.01
        warning('⚠ Robust is worse than Non-Robust at ε=%.2f! Something is wrong.', epsilon_set(eps_idx));
    end
end

%% ========================================================================
%  SAVE AND VISUALIZE RESULTS
%  ========================================================================

save('results_robust_csi.mat', 'results', 'SNR_dB_set', 'epsilon_set', ...
     'N', 'K', 'M', 'L', 'rho', 'Num_iter');

fprintf('\n=======================================================\n');
fprintf('Simulation Completed Successfully!\n');
fprintf('Results saved to: results_robust_csi.mat\n');
fprintf('=======================================================\n\n');

% Generate plots
plot_results(results, SNR_dB_set, epsilon_set);

fprintf('\n✅ All done! Check the generated plots.\n');