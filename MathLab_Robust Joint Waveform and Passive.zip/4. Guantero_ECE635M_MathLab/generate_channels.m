function [H_bu, H_br, H_ru] = generate_channels(N, K, L)
%% Generate Rayleigh Fading Channels
% Creates random Rayleigh fading channel matrices for RIS-ISAC system
%
% Inputs:
%   N - Number of base station antennas
%   K - Number of users
%   L - Number of RIS elements
%
% Outputs:
%   H_bu - Base station to user channel (K x N)
%   H_br - Base station to RIS channel (L x N)
%   H_ru - RIS to user channel (K x L)
%
% Channel Model:
%   Rayleigh fading: h ~ CN(0, 1)
%   Each element is complex Gaussian with zero mean and unit variance

% Generate complex Gaussian channels (Rayleigh fading)
H_bu = (randn(K, N) + 1j * randn(K, N)) / sqrt(2);
H_br = (randn(L, N) + 1j * randn(L, N)) / sqrt(2);
H_ru = (randn(K, L) + 1j * randn(K, L)) / sqrt(2);

end