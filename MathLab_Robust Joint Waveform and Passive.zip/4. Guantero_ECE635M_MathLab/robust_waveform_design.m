function [X_opt, THETA_opt] = robust_waveform_design(...
    H_bu, H_br, H_ru, S, F, M, P0, rho, N0, L, max_iteration, epsilon_tol, csi_error)
%% Robust Joint Waveform and RIS Reflection Design
% Enhanced version with stronger robustness mechanisms
%
% Key idea: Non-robust design overfits to estimated channels
%           Robust design hedges against worst-case errors

N = size(H_bu, 2);
K = size(H_bu, 1);

%% Apply robustness through worst-case channel modeling
if csi_error > 0
    % Strategy 1: Model multiple channel realizations (Monte Carlo robustness)
    num_worst_cases = 5;  % Number of worst-case scenarios to consider
    
    % Generate worst-case channel perturbations
    H_bu_scenarios = cell(num_worst_cases, 1);
    H_br_scenarios = cell(num_worst_cases, 1);
    H_ru_scenarios = cell(num_worst_cases, 1);
    
    for scenario = 1:num_worst_cases
        % Generate random error direction
        Delta_H_bu = (randn(K, N) + 1j * randn(K, N)) / sqrt(2);
        Delta_H_bu = csi_error * norm(H_bu, 'fro') * Delta_H_bu / norm(Delta_H_bu, 'fro');
        
        Delta_H_br = (randn(L, N) + 1j * randn(L, N)) / sqrt(2);
        Delta_H_br = csi_error * norm(H_br, 'fro') * Delta_H_br / norm(Delta_H_br, 'fro');
        
        Delta_H_ru = (randn(K, L) + 1j * randn(K, L)) / sqrt(2);
        Delta_H_ru = csi_error * norm(H_ru, 'fro') * Delta_H_ru / norm(Delta_H_ru, 'fro');
        
        % Worst-case: errors reduce channel quality
        H_bu_scenarios{scenario} = H_bu - Delta_H_bu * 0.8;  % Pessimistic assumption
        H_br_scenarios{scenario} = H_br - Delta_H_br * 0.8;
        H_ru_scenarios{scenario} = H_ru - Delta_H_ru * 0.8;
    end
    
    % Strategy 2: Conservative power allocation
    power_safety_factor = 1 - csi_error * 0.5;  % Reduce power budget
    P0_effective = P0 * power_safety_factor;
    
    % Strategy 3: Add diversity preference (avoid putting all eggs in one basket)
    diversity_penalty = csi_error * 2;
    
else
    % Non-robust: Use estimated channels as-is (aggressive)
    num_worst_cases = 1;
    H_bu_scenarios = {H_bu};
    H_br_scenarios = {H_br};
    H_ru_scenarios = {H_ru};
    P0_effective = P0;
    diversity_penalty = 0;
end

%% Initialize
THETA = eye(L);

% Initialize waveform
FHS0 = F' * H_bu' * S;
[U0, ~, V0] = svd(FHS0);
X = sqrt(M) * F * U0 * eye(N, M) * V0';
U = X;

delta = inf;
objective_old = inf;
iteration = 0;

%% Alternating optimization
while (delta > epsilon_tol) && (iteration < max_iteration)
    iteration = iteration + 1;
    
    %% Step 1: Update Waveform X (considering worst-case scenarios)
    if csi_error > 0
        % Robust: Optimize for worst-case across multiple scenarios
        A_combined = [];
        B_combined = [];
        
        for scenario = 1:num_worst_cases
            H_scenario = H_bu_scenarios{scenario} + ...
                        H_ru_scenarios{scenario} * THETA * H_br_scenarios{scenario};
            
            % Weight scenarios equally
            weight = sqrt(1 / num_worst_cases);
            A_combined = [A_combined; 
                         weight * sqrt(rho) * H_scenario; 
                         weight * sqrt(1 - rho) * eye(N)];
            B_combined = [B_combined; 
                         weight * sqrt(rho) * S; 
                         weight * sqrt(1 - rho) * U];
        end
        
        % Add diversity regularization
        A_combined = [A_combined; sqrt(diversity_penalty) * eye(N)];
        B_combined = [B_combined; zeros(N, M)];
        
        A = A_combined;
        B = B_combined;
    else
        % Non-robust: Single scenario (nominal channels)
        H = H_bu + H_ru * THETA * H_br;
        A = [sqrt(rho) * H; sqrt(1 - rho) * eye(N)];
        B = [sqrt(rho) * S; sqrt(1 - rho) * U];
    end
    
    % Solve power-constrained least squares
    Q = A' * A;
    G = A' * B;
    
    % Numerical stability
    Q = (Q + Q') / 2;
    Q = Q + 1e-8 * eye(N);
    
    [V_Q, D_Q] = eig(Q);
    lambda = diag(D_Q);
    lambda_min = min(real(lambda));
    
    % Bisection for power constraint
    u1 = max(-lambda_min, 1e-6);
    u2 = 100;
    
    power_limit = M * P0_effective;
    
    while abs(u2 - u1) > 1e-6
        u3 = (u2 + u1) / 2;
        X_temp = (V_Q * inv(D_Q + u3 * eye(N)) * V_Q') * G;
        P_u3 = norm(X_temp, 'fro')^2;
        
        if P_u3 > power_limit
            u1 = u3;
        else
            u2 = u3;
        end
    end
    
    X = (V_Q * inv(D_Q + u3 * eye(N)) * V_Q') * G;
    
    %% Step 2: Update U
    FX = F' * X;
    [U_bar, ~, V_bar] = svd(FX);
    U = sqrt(M) * F * U_bar * eye(N, M) * V_bar';
    
    %% Step 3: Update THETA (considering worst-case scenarios)
    if csi_error > 0
        % Robust: Optimize for worst-case
        B_C_total = zeros(L, L);
        d_vec_total = zeros(L, 1);
        
        for scenario = 1:num_worst_cases
            H_bu_s = H_bu_scenarios{scenario};
            H_br_s = H_br_scenarios{scenario};
            H_ru_s = H_ru_scenarios{scenario};
            
            B_matrix = H_ru_s' * H_ru_s;
            C_matrix = H_br_s * X * X' * H_br_s';
            T = H_bu_s * X - S;
            D_matrix = H_br_s * X * T' * H_ru_s;
            d_vec = diag(D_matrix);
            
            B_C_total = B_C_total + (B_matrix .* C_matrix.') / num_worst_cases;
            d_vec_total = d_vec_total + d_vec / num_worst_cases;
        end
        
        B_C = B_C_total;
        d_vec = d_vec_total;
        
        % Add stability regularization
        B_C = B_C + diversity_penalty * 0.1 * eye(L);
    else
        % Non-robust: Single scenario
        H_bu_s = H_bu;
        H_br_s = H_br;
        H_ru_s = H_ru;
        
        B_matrix = H_ru_s' * H_ru_s;
        C_matrix = H_br_s * X * X' * H_br_s';
        T = H_bu_s * X - S;
        D_matrix = H_br_s * X * T' * H_ru_s;
        d_vec = diag(D_matrix);
        B_C = B_matrix .* C_matrix.';
    end
    
    % Ensure Hermitian
    B_C = (B_C + B_C') / 2;
    
    % Manifold optimization
    manifold = complexcirclefactory(L);
    problem.M = manifold;
    problem.cost = @(x) real(x' * B_C * x + d_vec.' * x + x' * conj(d_vec));
    problem.egrad = @(x) 2 * B_C * x + 2 * conj(d_vec);
    
    options.verbosity = 0;
    options.maxiter = 100;
    
    [theta_vec, ~, ~, ~] = steepestdescent(problem, [], options);
    THETA = diag(theta_vec);
    
    %% Convergence check (use nominal channels)
    H = H_bu + H_ru * THETA * H_br;
    A = [sqrt(rho) * H; sqrt(1 - rho) * eye(N)];
    B = [sqrt(rho) * S; sqrt(1 - rho) * U];
    
    objective_new = norm(A * X - B, 'fro')^2;
    delta = abs(objective_old - objective_new);
    objective_old = objective_new;
end

X_opt = X;
THETA_opt = THETA;

end