function sum_rate = compute_sum_rate(H, X, S, N0, K)
%% Compute Sum Communication Rate
% This function calculates the sum rate for all users in the system
%
% Inputs:
%   H  - Effective channel matrix (K x N)
%        K = number of users, N = number of antennas
%   X  - Waveform/precoding matrix (N x M)
%        M = number of symbols
%   S  - Transmitted symbol matrix (K x M)
%   N0 - Noise power spectral density
%   K  - Number of users
%
% Output:
%   sum_rate - Sum of achievable rates for all users (bits/s/Hz)
%
% Rate Calculation:
%   For each user k: Rate_k = log2(1 + SINR_k)
%   where SINR_k = signal power / (interference + noise)
%
% Example:
%   H = randn(4, 20) + 1j*randn(4, 20);
%   X = randn(20, 30) + 1j*randn(20, 30);
%   S = randi(2, 4, 30) * 2 - 3;
%   N0 = 0.1;
%   K = 4;
%   rate = compute_sum_rate(H, X, S, N0, K);

% Initialize rate vector
rate = zeros(K, 1);

% Compute rate for each user
for k = 1:K
    % Received signal for user k
    received_signal = H(k, :) * X;
    
    % Desired signal for user k
    desired_signal = S(k, :);
    
    % Compute Mean Squared Error (MSE)
    % MSE represents the combined effect of multi-user interference
    % and estimation error
    error_signal = received_signal - desired_signal;
    MSE = mean(abs(error_signal).^2);
    
    % Compute Signal-to-Interference-plus-Noise Ratio (SINR)
    % SINR = 1 / (MSE + N0)
    % Higher MSE means lower SINR
    SINR = 1 / (MSE + N0);
    
    % Compute achievable rate using Shannon capacity formula
    % Rate = log2(1 + SINR) bits/s/Hz
    rate(k) = log2(1 + SINR);
end

% Sum rate across all users
sum_rate = sum(rate);

% Optional: Handle edge cases
if isnan(sum_rate) || isinf(sum_rate)
    warning('Invalid sum rate computed. Check input parameters.');
    sum_rate = 0;
end

end