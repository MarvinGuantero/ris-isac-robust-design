function sum_rate = compute_sum_rate(H, X, S, N0, K)
%% Compute Sum Communication Rate
% Inputs:
%   H - Effective channel matrix (K x N)
%   X - Waveform matrix (N x M)
%   S - Symbol matrix (K x M)
%   N0 - Noise power
%   K - Number of users
% Output:
%   sum_rate - Sum rate in bits/s/Hz

rate = zeros(K, 1);

for k = 1:K
    % Multi-user interference + signal
    received_signal = H(k, :) * X;
    desired_signal = S(k, :);
    
    % Mean squared error
    MSE = mean(abs(received_signal - desired_signal).^2);
    
    % SINR and rate
    SINR = 1 / (MSE + N0);
    rate(k) = log2(1 + SINR);
end

sum_rate = sum(rate);

end


function [radar_mse, comm_rate, total_objective] = ...
    compute_full_metrics(H, X, S, N0, K, F, rho)
%% Compute All Performance Metrics
% Outputs:
%   radar_mse - Radar pattern matching error
%   comm_rate - Communication sum rate
%   total_objective - Combined objective

% Communication rate
comm_rate = compute_sum_rate(H, X, S, N0, K);

% Radar pattern error
radar_mse = norm(F' * X, 'fro')^2;

% Total objective (trade-off)
total_objective = rho * radar_mse + (1 - rho) * (-comm_rate);

end