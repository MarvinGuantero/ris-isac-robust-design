function [radar_mse, comm_rate, total_objective] = ...
    compute_full_metrics(H, X, S, N0, K, F, rho)
%% Compute All Performance Metrics for RIS-ISAC System
% 
% This function evaluates both radar and communication performance
% for the dual-functional RIS-ISAC system
%
% Inputs:
%   H   - Effective channel matrix (K x N)
%   X   - Waveform matrix (N x M)
%   S   - Symbol matrix (K x M)
%   N0  - Noise power
%   K   - Number of users
%   F   - Cholesky factor of desired radar pattern
%   rho - Trade-off parameter (0 to 1)
%         rho = 1: pure radar, rho = 0: pure communication
%
% Outputs:
%   radar_mse       - Radar pattern matching error (lower is better)
%   comm_rate       - Communication sum rate in bits/s/Hz (higher is better)
%   total_objective - Combined weighted objective
%
% Objective Function:
%   J = rho * (radar_mse) + (1-rho) * (-comm_rate)
%   Minimizing J balances radar and communication performance

%% Communication Performance
% Compute sum rate for all users
comm_rate = compute_sum_rate(H, X, S, N0, K);

%% Radar Performance
% Measure how well the transmitted waveform matches desired radar pattern
% Desired pattern: R_d with Cholesky decomposition R_d = F * F'
% Actual pattern: X * X'
% Error: ||F' * X - desired||_F^2

radar_pattern_actual = F' * X;
radar_mse = norm(radar_pattern_actual, 'fro')^2;

%% Combined Objective (Trade-off)
% Balance between radar and communication
% Minimizing this objective means:
%   - Better radar performance (lower MSE)
%   - Better communication (higher rate, but we negate it for minimization)

total_objective = rho * radar_mse - (1 - rho) * comm_rate;

end