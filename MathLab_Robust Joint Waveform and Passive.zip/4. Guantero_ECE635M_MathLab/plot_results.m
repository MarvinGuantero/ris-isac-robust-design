function plot_results(results, SNR_dB_set, epsilon_set)
%% Generate Comprehensive Result Plots

% Create figure with multiple subplots
figure('Position', [100, 100, 1400, 900]);

%% Plot 1: Sum Rate vs SNR for different CSI errors
subplot(2, 2, 1);
hold on; grid on; box on;

colors = lines(length(epsilon_set));
for eps_idx = 1:length(epsilon_set)
    plot(SNR_dB_set, results(eps_idx).rate_robust_avg, ...
         '-o', 'LineWidth', 2, 'MarkerSize', 8, ...
         'DisplayName', sprintf('\\epsilon = %.2f', epsilon_set(eps_idx)), ...
         'Color', colors(eps_idx, :));
end

xlabel('SNR (dB)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Sum Rate (bits/s/Hz)', 'FontSize', 12, 'FontWeight', 'bold');
title('Robust Design: Sum Rate vs SNR', 'FontSize', 14, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 10);
set(gca, 'FontSize', 11);

%% Plot 2: Comparison - Robust vs Non-Robust (for epsilon = 0.1)
subplot(2, 2, 2);
eps_idx_compare = 3; % epsilon = 0.1
hold on; grid on; box on;

plot(SNR_dB_set, results(1).rate_perfect_avg, '-bs', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'DisplayName', 'Perfect CSI', 'MarkerFaceColor', 'b');
plot(SNR_dB_set, results(eps_idx_compare).rate_robust_avg, '-ro', ...
     'LineWidth', 2.5, 'MarkerSize', 10, 'DisplayName', 'Robust Design', 'MarkerFaceColor', 'r');
plot(SNR_dB_set, results(eps_idx_compare).rate_nonrobust_avg, '--gd', ...
     'LineWidth', 2, 'MarkerSize', 10, 'DisplayName', 'Non-Robust Design', 'MarkerFaceColor', 'g');

xlabel('SNR (dB)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Sum Rate (bits/s/Hz)', 'FontSize', 12, 'FontWeight', 'bold');
title(sprintf('Performance Gap (\\epsilon = %.2f)', epsilon_set(eps_idx_compare)), ...
      'FontSize', 14, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 10);
set(gca, 'FontSize', 11);

%% Plot 3: Performance Degradation vs CSI Error
subplot(2, 2, 3);
hold on; grid on; box on;

% Choose mid-range SNR for comparison
snr_compare_idx = ceil(length(SNR_dB_set) / 2);

degradation_robust = zeros(length(epsilon_set), 1);
degradation_nonrobust = zeros(length(epsilon_set), 1);

perfect_rate = results(1).rate_perfect_avg(snr_compare_idx);

for eps_idx = 1:length(epsilon_set)
    % Degradation = (Perfect - Actual) / Perfect * 100
    degradation_robust(eps_idx) = ...
        max(0, (perfect_rate - results(eps_idx).rate_robust_avg(snr_compare_idx)) / perfect_rate * 100);
    degradation_nonrobust(eps_idx) = ...
        max(0, (perfect_rate - results(eps_idx).rate_nonrobust_avg(snr_compare_idx)) / perfect_rate * 100);
end

plot(epsilon_set, degradation_robust, '-ro', ...
     'LineWidth', 2.5, 'MarkerSize', 12, 'DisplayName', 'Robust Design', 'MarkerFaceColor', 'r');
plot(epsilon_set, degradation_nonrobust, '--gd', ...
     'LineWidth', 2.5, 'MarkerSize', 12, 'DisplayName', 'Non-Robust Design', 'MarkerFaceColor', 'g');

xlabel('CSI Error Bound (\epsilon)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Performance Degradation (%)', 'FontSize', 12, 'FontWeight', 'bold');
title(sprintf('Robustness Comparison (SNR = %d dB)', SNR_dB_set(snr_compare_idx)), ...
      'FontSize', 14, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 10);
grid on;
set(gca, 'FontSize', 11);

% Validation check
if any(degradation_robust > degradation_nonrobust + 1)
    warning('⚠ Plot 3: Robust shows MORE degradation than Non-Robust! Check algorithm.');
    text(mean(epsilon_set), max(degradation_robust)*0.8, ...
         '⚠ WARNING: Unexpected ordering!', 'Color', 'r', 'FontSize', 12, 'FontWeight', 'bold');
end

%% Plot 4: Robustness Gain (Robust - Non-Robust)
subplot(2, 2, 4);
hold on; grid on; box on;

robustness_gain = zeros(length(epsilon_set), length(SNR_dB_set));

for eps_idx = 1:length(epsilon_set)
    for snr_idx = 1:length(SNR_dB_set)
        % Gain = Robust - Non-Robust (should be positive!)
        robustness_gain(eps_idx, snr_idx) = ...
            results(eps_idx).rate_robust_avg(snr_idx) - ...
            results(eps_idx).rate_nonrobust_avg(snr_idx);
    end
end

for eps_idx = 2:length(epsilon_set)  % Skip epsilon=0
    plot(SNR_dB_set, robustness_gain(eps_idx, :), '-o', ...
         'LineWidth', 2, 'MarkerSize', 8, ...
         'DisplayName', sprintf('\\epsilon = %.2f', epsilon_set(eps_idx)));
end

% Add zero reference line
plot(SNR_dB_set, zeros(size(SNR_dB_set)), 'k--', 'LineWidth', 1, 'HandleVisibility', 'off');

xlabel('SNR (dB)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Rate Gain (bits/s/Hz)', 'FontSize', 12, 'FontWeight', 'bold');
title('Robustness Gain: Robust vs Non-Robust', 'FontSize', 14, 'FontWeight', 'bold');
legend('Location', 'best', 'FontSize', 10);
grid on;
set(gca, 'FontSize', 11);

% Validation check
if any(robustness_gain(:) < -0.01)
    warning('⚠ Plot 4: Negative gains detected! Robust should always be better.');
    text(mean(SNR_dB_set), min(robustness_gain(:))*1.2, ...
         '⚠ WARNING: Negative gains!', 'Color', 'r', 'FontSize', 12, 'FontWeight', 'bold');
end

% Save figure
saveas(gcf, 'results_robust_csi_plots.png');
saveas(gcf, 'results_robust_csi_plots.fig');

fprintf('\nPlots saved as: results_robust_csi_plots.png and .fig\n');

%% Generate numerical summary table
fprintf('\n=======================================================\n');
fprintf('NUMERICAL RESULTS SUMMARY\n');
fprintf('=======================================================\n\n');

fprintf('Average Sum Rate at SNR = %d dB:\n', SNR_dB_set(end));
fprintf('%-20s %-15s %-15s %-15s %-15s\n', 'CSI Error (ε)', 'Perfect CSI', 'Robust', 'Non-Robust', 'Gain');
fprintf('-------------------------------------------------------------------------------\n');

for eps_idx = 1:length(epsilon_set)
    gain = results(eps_idx).rate_robust_avg(end) - results(eps_idx).rate_nonrobust_avg(end);
    fprintf('%-20.2f %-15.2f %-15.2f %-15.2f %-15.2f\n', ...
            epsilon_set(eps_idx), ...
            results(1).rate_perfect_avg(end), ...
            results(eps_idx).rate_robust_avg(end), ...
            results(eps_idx).rate_nonrobust_avg(end), ...
            gain);
end

fprintf('\n=======================================================\n\n');

end