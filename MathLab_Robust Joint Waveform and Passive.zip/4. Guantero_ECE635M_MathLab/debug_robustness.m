%% Debug Script: Check if Robust Design is Working
close all; clear all; clc;

% Simple test case
N = 20; K = 4; M = 30; L = 16;
P0_dbm = 20;
P0 = 10^(P0_dbm/10) / 1e3;
SNR_dB = 10;
SNR = 10^(SNR_dB/10);
N0 = 1/SNR;
rho = 0.2;
max_iteration = 50;
epsilon_tol = 0.01;

load Rd.mat;
F = chol(Rd);

% Generate test case
S = randi(2, K, M) * 2 - 3;
[H_bu_true, H_br_true, H_ru_true] = generate_channels(N, K, L);

% Test different CSI error levels
epsilon_test = [0, 0.1, 0.2];
results_test = struct();

fprintf('\n========== ROBUSTNESS TEST ==========\n\n');

for i = 1:length(epsilon_test)
    epsilon = epsilon_test(i);
    fprintf('Testing ε = %.2f\n', epsilon);
    
    if epsilon == 0
        H_bu_est = H_bu_true;
        H_br_est = H_br_true;
        H_ru_est = H_ru_true;
    else
        [H_bu_est, H_br_est, H_ru_est] = ...
            generate_channels_with_error(H_bu_true, H_br_true, H_ru_true, epsilon);
    end
    
    % Robust design
    fprintf('  Running ROBUST design...\n');
    [X_robust, THETA_robust] = ...
        robust_waveform_design(H_bu_est, H_br_est, H_ru_est, ...
        S, F, M, P0, rho, N0, L, max_iteration, epsilon_tol, epsilon);
    
    H_robust = H_bu_true + H_ru_true * THETA_robust * H_br_true;
    rate_robust = compute_sum_rate(H_robust, X_robust, S, N0, K);
    
    % Non-robust design
    fprintf('  Running NON-ROBUST design...\n');
    [X_nonrobust, THETA_nonrobust] = ...
        robust_waveform_design(H_bu_est, H_br_est, H_ru_est, ...
        S, F, M, P0, rho, N0, L, max_iteration, epsilon_tol, 0);
    
    H_nonrobust = H_bu_true + H_ru_true * THETA_nonrobust * H_br_true;
    rate_nonrobust = compute_sum_rate(H_nonrobust, X_nonrobust, S, N0, K);
    
    % Store results
    results_test(i).epsilon = epsilon;
    results_test(i).rate_robust = rate_robust;
    results_test(i).rate_nonrobust = rate_nonrobust;
    results_test(i).gain = rate_robust - rate_nonrobust;
    
    % Display
    fprintf('  Robust rate:     %.4f bits/s/Hz\n', rate_robust);
    fprintf('  Non-robust rate: %.4f bits/s/Hz\n', rate_nonrobust);
    fprintf('  Gain:            %.4f bits/s/Hz ', rate_robust - rate_nonrobust);
    
    if rate_robust > rate_nonrobust
        fprintf('✓ GOOD\n');
    else
        fprintf('✗ BAD - Robust should be better!\n');
    end
    fprintf('\n');
end

fprintf('========================================\n\n');

% Plot comparison
figure('Position', [100, 100, 800, 600]);
bar_data = [[results_test.rate_robust]', [results_test.rate_nonrobust]'];
b = bar([results_test.epsilon], bar_data);
b(1).FaceColor = 'r';
b(2).FaceColor = 'g';
xlabel('CSI Error (ε)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Sum Rate (bits/s/Hz)', 'FontSize', 12, 'FontWeight', 'bold');
title('Debug: Robust vs Non-Robust', 'FontSize', 14, 'FontWeight', 'bold');
legend('Robust', 'Non-Robust', 'Location', 'best');
grid on;

% Add gain labels
for i = 1:length(epsilon_test)
    gain = results_test(i).gain;
    x_pos = i;
    y_pos = max(results_test(i).rate_robust, results_test(i).rate_nonrobust) + 0.1;
    if gain > 0
        text(x_pos, y_pos, sprintf('Gain: +%.3f', gain), ...
             'HorizontalAlignment', 'center', 'Color', 'b', 'FontWeight', 'bold');
    else
        text(x_pos, y_pos, sprintf('Gain: %.3f ⚠', gain), ...
             'HorizontalAlignment', 'center', 'Color', 'r', 'FontWeight', 'bold');
    end
end

saveas(gcf, 'debug_robustness.png');
fprintf('Debug plot saved as debug_robustness.png\n');