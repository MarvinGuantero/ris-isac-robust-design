function [H_bu_est, H_br_est, H_ru_est] = ...
    generate_channels_with_error(H_bu_true, H_br_true, H_ru_true, epsilon)
%% Generate Estimated Channels with Bounded CSI Errors
% This function models imperfect channel state information (CSI)
% by adding bounded estimation errors to the true channels
%
% CSI Error Model:
%   H_estimated = H_true + Delta_H
%   where ||Delta_H||_F <= epsilon * ||H_true||_F
%
% The error is bounded relative to the true channel strength
%
% Inputs:
%   H_bu_true - True base station to user channel (K x N)
%   H_br_true - True base station to RIS channel (L x N)
%   H_ru_true - True RIS to user channel (K x L)
%   epsilon   - CSI error bound (relative to channel norm)
%               epsilon = 0.0 means perfect CSI
%               epsilon = 0.1 means 10% error bound
%               epsilon = 0.2 means 20% error bound
%
% Outputs:
%   H_bu_est - Estimated base station to user channel
%   H_br_est - Estimated base station to RIS channel
%   H_ru_est - Estimated RIS to user channel
%
% Error Generation Process:
%   1. Generate random complex Gaussian error matrix
%   2. Normalize error to have the desired bounded norm
%   3. Add error to true channel
%
% Example:
%   [H_bu, H_br, H_ru] = generate_channels(20, 4, 16);
%   epsilon = 0.1;  % 10% CSI error
%   [H_bu_est, H_br_est, H_ru_est] = ...
%       generate_channels_with_error(H_bu, H_br, H_ru, epsilon);

%% Generate Error for H_bu
% Create random complex Gaussian error with same dimensions as H_bu_true
Delta_H_bu = (randn(size(H_bu_true)) + 1j * randn(size(H_bu_true))) / sqrt(2);

% Compute the Frobenius norm of the true channel
norm_H_bu = norm(H_bu_true, 'fro');

% Normalize error to have bounded norm: ||Delta_H_bu||_F = epsilon * ||H_bu_true||_F
norm_Delta_H_bu = norm(Delta_H_bu, 'fro');
Delta_H_bu = epsilon * norm_H_bu * Delta_H_bu / norm_Delta_H_bu;

% Add error to true channel
H_bu_est = H_bu_true + Delta_H_bu;

%% Generate Error for H_br
% Same process for base station to RIS channel
Delta_H_br = (randn(size(H_br_true)) + 1j * randn(size(H_br_true))) / sqrt(2);
norm_H_br = norm(H_br_true, 'fro');
norm_Delta_H_br = norm(Delta_H_br, 'fro');
Delta_H_br = epsilon * norm_H_br * Delta_H_br / norm_Delta_H_br;
H_br_est = H_br_true + Delta_H_br;

%% Generate Error for H_ru
% Same process for RIS to user channel
Delta_H_ru = (randn(size(H_ru_true)) + 1j * randn(size(H_ru_true))) / sqrt(2);
norm_H_ru = norm(H_ru_true, 'fro');
norm_Delta_H_ru = norm(Delta_H_ru, 'fro');
Delta_H_ru = epsilon * norm_H_ru * Delta_H_ru / norm_Delta_H_ru;
H_ru_est = H_ru_true + Delta_H_ru;

%% Verification (Optional - for debugging)
% Uncomment to verify that error bounds are satisfied
% error_ratio_bu = norm(H_bu_est - H_bu_true, 'fro') / norm(H_bu_true, 'fro');
% error_ratio_br = norm(H_br_est - H_br_true, 'fro') / norm(H_br_true, 'fro');
% error_ratio_ru = norm(H_ru_est - H_ru_true, 'fro') / norm(H_ru_true, 'fro');
% fprintf('Error ratios - H_bu: %.4f, H_br: %.4f, H_ru: %.4f (should be ~%.2f)\n', ...
%         error_ratio_bu, error_ratio_br, error_ratio_ru, epsilon);

end