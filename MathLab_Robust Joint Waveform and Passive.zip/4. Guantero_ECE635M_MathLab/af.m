function a = af(theta, N)
%% Array Factor Function
% Computes steering vector for uniform linear array
% Inputs:
%   theta - Angle in radians
%   N - Number of antenna elements
% Output:
%   a - Steering vector (N x 1)

a = zeros(N, 1);
for l = 1:N
    a(l) = exp(1j * 2 * pi * 0.5 * (l - 1) * sin(theta));
end

end